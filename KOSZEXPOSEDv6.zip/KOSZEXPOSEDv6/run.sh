export FLASK_APP=kosz.py
export FLASK_ENV=development
flask run
