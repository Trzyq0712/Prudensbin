# Nasze API
Wszystkie zapytania ida po POST
Parametry to stringi chyba, ze napisano inaczej
- `/create` : location, content

# Bintype
P - papier
S - szkło
M - metal
E - elektrosmieci (bez baterii)
T - plastik / tworzywa sztuczne
L - leki
B - baterie